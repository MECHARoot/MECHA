function []=Hydr_xml(Input_path,Output_path,kw,kw_barrier,kAQP,Kpl,Contact,MECHA_version)

HYDR=fopen([Input_path '/Hydraulics_optim.xml'],'w');
fprintf(HYDR,'%s\r\n','<?xml version="1.0" encoding="utf-8"?>');
fprintf(HYDR,'%s\r\n','<!-- Hydraulic options -->');
fprintf(HYDR,'%s\r\n',' ');
fprintf(HYDR,'%s\r\n','<param>');
fprintf(HYDR,'%s\r\n','        <!-- Path to the folders of different hydraulic scenarios -->');
fprintf(HYDR,'%s\r\n','        <path_hydraulics> <!-- By order of selected property: Xcontact / leakiness / kw / Kpd / kAQP -->');
fprintf(HYDR,'%s\r\n',['            <Output path=''' Output_path '/''/>']);
fprintf(HYDR,'%s\r\n','        </path_hydraulics>');
fprintf(HYDR,'%s\r\n','        <!-- Cell wall hydraulic conductivity');
fprintf(HYDR,'%s\r\n','             Review in Transport in plants II: Part B Tissues and Organs, A. Lauchli: 1. Apoplasmic transport in tissues');
fprintf(HYDR,'%s\r\n','             Units: cm^2/hPa/d');
fprintf(HYDR,'%s\r\n','             6.6E-03: Soybean hypocotyl Steudle and Boyer (1985)');
fprintf(HYDR,'%s\r\n','			    2.4E-04: Zhu and Steudle (1991)');
fprintf(HYDR,'%s\r\n','             1.2E-05: Nitella cell Tyree (1968)');
fprintf(HYDR,'%s\r\n','             6.0E-06: Nitella cell walls Zimmermann and Steudle (1975)');
fprintf(HYDR,'%s\r\n','             1.3E-7:  Cellulose wall Briggs (1967) for thickness of 1.5 micron');
fprintf(HYDR,'%s\r\n','             1.8E-9:  Maize root cell wall Tyree (1973) for thickness of 1.5 micron -->');
fprintf(HYDR,'%s\r\n','        <kwrange>');
fprintf(HYDR,'%s\r\n',['            <kw value="' num2str(kw,'%11.9e') '" /> <!-- hydraulic conductivity of standard walls -->']);
fprintf(HYDR,'%s\r\n','        </kwrange>');
fprintf(HYDR,'%s\r\n','        <!-- Apoplastic barrier conductivity');
fprintf(HYDR,'%s\r\n','             Units: cm^2/hPa/d');
fprintf(HYDR,'%s\r\n','             4.3E-07: 1 nanometer pores, Poiseuille law');
fprintf(HYDR,'%s\r\n','             1.0E-16: Virtually impermeable');
fprintf(HYDR,'%s\r\n','             Casp concerns the hydraulic conductivity of lignin in radial walls of "gatekeeper cells" (endodermis/exodermis), while "Sub" concerns the hydraulic conductivity of suberized secondary walls-->');
fprintf(HYDR,'%s\r\n','        <kw_barrier_range> <!-- hydraulic conductivity of suberised and lignified walls -->');
if strcmp(MECHA_version(end-11:end),'UniXwalls.py') || strcmp(MECHA_version(end-8:end),'optim3.py')
    for i=1:length(kw_barrier)
        if kw_barrier(i)==1
            fprintf(HYDR,'%s\r\n',['            <kw_barrier value="' num2str(kw,'%11.9e') '" />']);
        else
            fprintf(HYDR,'%s\r\n',['            <kw_barrier value="' num2str(kw_barrier(i),'%6.4e') '" />']);
        end
    end
else
    for i=1:length(kw_barrier)
        if kw_barrier(i)==1
            fprintf(HYDR,'%s\r\n',['            <kw_barrier Casp="' num2str(kw,'%11.9e') '" Sub="1.0E-16" />']);
        else
            fprintf(HYDR,'%s\r\n',['            <kw_barrier Casp="' num2str(kw_barrier(i),'%6.4e') '" Sub="1.0E-16" />']);
        end
    end
end
fprintf(HYDR,'%s\r\n','        </kw_barrier_range>');
fprintf(HYDR,'%s\r\n','        ');
fprintf(HYDR,'%s\r\n','        <!-- Cell membrane permeability, with separate contribution of the biphospholipid layer (km) and AQP (kAQP)');
fprintf(HYDR,'%s\r\n','             Attention, kaqp==0 is used as flag for each air-filled intercellular space, and cancels any flow across the membrane (as if km was equal to 0 too)');
fprintf(HYDR,'%s\r\n','             For knocked out AQPs, please use a very small value, such as 1.0E-16');
fprintf(HYDR,'%s\r\n','             Units: cm/hPa/d');
fprintf(HYDR,'%s\r\n','             6.8E-5 to 1.9E-4: Lp Steudle and Jeschke (1983)');
fprintf(HYDR,'%s\r\n','             4.3E-4: kAQP Elhert et al. (2009), difference in maize cell hydraulic conductivity between control and acid-treated cells (AQP closed)');
fprintf(HYDR,'%s\r\n','             3.0E-5: km after removal of kAQP and kpl from Elhert et al. (2009) and Bret-Hart and Silk (1994)-->');
fprintf(HYDR,'%s\r\n','        <km value="3.0E-5" />');
fprintf(HYDR,'%s\r\n','        <kAQPrange>');
fprintf(HYDR,'%s\r\n',['            <kAQP value="' num2str(kAQP,'%11.9e') '"  epi_factor="1.0" exo_factor="1.0" cortex_factor="1.0" endo_factor="1.0" stele_factor="1.0" />']);
fprintf(HYDR,'%s\r\n','        </kAQPrange>');
fprintf(HYDR,'%s\r\n','        <ratio_cortex value="1.0"/> <!-- (-) ratio of cell membranes hydraulic conductivity between inner and outer cortex -->');
fprintf(HYDR,'%s\r\n',' ');
fprintf(HYDR,'%s\r\n','        <!-- Individual plasmodesma conductance and plasmodesmatal frequency');
fprintf(HYDR,'%s\r\n','             Kpl Units: cm^3/hPa/d/plasmodesmata');
fprintf(HYDR,'%s\r\n','             9.1E-13: Very low Kpl (extrapolation)');
fprintf(HYDR,'%s\r\n','             5.3E-12: Geometrical average from Bret-Hart and Silk (1994)');
fprintf(HYDR,'%s\r\n','             3.1E-11: Estimation from Ginsburg & Ginzburg (1970)');
fprintf(HYDR,'%s\r\n','             ');
fprintf(HYDR,'%s\r\n','             Frequency*height is the conserved quantity when height changes (default height in measured tissue assumed to be 100 microns)');
fprintf(HYDR,'%s\r\n','             Measurements reported below come from elongated maize cell (~100 microns)');
fprintf(HYDR,'%s\r\n','             Fpl by height Units: plasodesmata*cm/cm^2');
fprintf(HYDR,'%s\r\n','             3.5E5: Default average (0.35/micron^2 * 100 microns)');
fprintf(HYDR,'%s\r\n','             1.3E5: height * Plasmodesmal frequency between epidermis and cortex from Zhu et al. (1998)');
fprintf(HYDR,'%s\r\n','             5.1E5: height * Plasmodesmal frequency between cortex and cortex from Zhu et al. (1998)');
fprintf(HYDR,'%s\r\n','             2.6E5: height * Plasmodesmal frequency between cortex and endodermis from Zhu et al. (1998)');
fprintf(HYDR,'%s\r\n','             3.1E5: height * Plasmodesmal frequency between endodermis and endodermis from Zhu et al. (1998)');
fprintf(HYDR,'%s\r\n','             3.0E5: height * Plasmodesmal frequency between endodermis and pericycle from Zhu et al. (1998)');
fprintf(HYDR,'%s\r\n','             3.5E5: height * Plasmodesmal frequency between stele and stele (parenchyma) from Zhu et al. (1998) -->');
fprintf(HYDR,'%s\r\n','        <Kplrange>');
fprintf(HYDR,'%s\r\n',['            <Kpl value="' num2str(Kpl,'%11.9e') '" cortex_factor="1.0" PCC_factor="1.0" PPP_factor="1.0" PST_factor="1.0" />']);
fprintf(HYDR,'%s\r\n','        </Kplrange>');
fprintf(HYDR,'%s\r\n','        <Freq_source value="1"/> <!-- 1: Hydraulics file (based on tissue type); 2: CellSet output file (wall per wall) -->');
fprintf(HYDR,'%s\r\n','        <Freq_factor value="1.0"/> <!-- Multiplies all PD frequencies -->');
fprintf(HYDR,'%s\r\n','        <Fplxheight value="3.5E5"/> <!-- Default height * plasmodesmatal frequency -->');
fprintf(HYDR,'%s\r\n','        <Fplxheight_epi_exo value="3.5E5"/> ');
fprintf(HYDR,'%s\r\n','        <Fplxheight_outer_cortex value="1.3E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_cortex_cortex value="5.1E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_cortex_endo value="2.6E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_endo_endo value="3.1E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_endo_peri value="3.0E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_peri_peri value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_peri_stele value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_stele_stele value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_stele_comp value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_peri_comp value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_comp_comp value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_comp_sieve value="9.0E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_peri_sieve value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Fplxheight_stele_sieve value="3.5E5"/>');
fprintf(HYDR,'%s\r\n','        <Defheight value="100"/> <!-- Default height (microns) -->');
fprintf(HYDR,'%s\r\n','        ');
fprintf(HYDR,'%s\r\n','        <!-- Axial conductances (cm^3/hPa/d) -->');
fprintf(HYDR,'%s\r\n','        <Kax_source value="1"/> <!-- 1: Poiseuille law (based on cross-section area); 2: Prescribed here below (for all sieve tubes, and vessel per vessel) -->');
fprintf(HYDR,'%s\r\n','        <K_sieve_range> <!-- Xylem vessel hydraulic conductance (cm^3/hPa/d) -->');
fprintf(HYDR,'%s\r\n','            <K_sieve id="38" value="4.0E-5"/> <!-- raw estimation -->');
fprintf(HYDR,'%s\r\n','            <K_sieve id="40" value="4.0E-5"/>');
fprintf(HYDR,'%s\r\n','            <K_sieve id="50" value="4.0E-5"/>');
fprintf(HYDR,'%s\r\n','            <K_sieve id="55" value="4.0E-5"/>');
fprintf(HYDR,'%s\r\n','        </K_sieve_range>');
fprintf(HYDR,'%s\r\n','        <K_xyl_range> <!-- Xylem vessel hydraulic conductance (cm^3/hPa/d) -->');
fprintf(HYDR,'%s\r\n','            <K_xyl id="24" value="1.1E-03"/> <!-- estimation based on transverse surface area -->');
fprintf(HYDR,'%s\r\n','            <K_xyl id="29" value="6.7E-03"/>');
fprintf(HYDR,'%s\r\n','            <K_xyl id="43" value="4.5E-03"/>');
fprintf(HYDR,'%s\r\n','            <K_xyl id="51" value="8.0E-03"/>');
fprintf(HYDR,'%s\r\n','            <K_xyl id="67" value="7.6E-04"/>');
fprintf(HYDR,'%s\r\n','        </K_xyl_range>');
fprintf(HYDR,'%s\r\n','        ');
fprintf(HYDR,'%s\r\n','        <!-- Xcontact (microns) is the X threshold coordinate of contact between soil and root (lower X not in contact with soil)  -->');
fprintf(HYDR,'%s\r\n','        <!-- Note that contact is also dealt with in the *Geometry.xml input file where the id''s of cells in contact with the soil are listed  -->');
fprintf(HYDR,'%s\r\n','        <Xcontactrange>');
for i=1:length(Contact)
    fprintf(HYDR,'%s\r\n',['            <Xcontact value="' num2str(Contact(i)) '"/> <!-- Arabido1: 120 microns includes 1 cell, 109 microns includes 5 cells to the right -->']);
end
fprintf(HYDR,'%s\r\n','        </Xcontactrange>');
fprintf(HYDR,'%s\r\n','</param>');
fclose ('all');