
*******************************************************
*Use of MECHA and associated inverse modelling program*
*******************************************************

1. System requirements
The current version of MECHA works in the Anaconda environment and was developed on Windows 10 with the IDE Spyder 3.3.6.
A Matlab license is required to run the inverse modelling program. Versions dating back to MatlabR2010a have been successfully tested.
The code currently uses the search algorithm fmincon or other algorithms from the Global Optimization toolbox of Matlab.

2. Installation guide
To install Anaconda (free), you can follow this guide: https://docs.anaconda.com/anaconda/install/index.html
Running the latest version of MECHA (MECHA_4Dsolute.py) requires Python 3.7 and the installation of the following libraries:
    numpy
    scipy
    networkx 1.9.1
    lxml
When first opening "MECHA_4Dsolute.py" (e.g. in the Spyder IDE), one needs to update the directory referred to at line 5 of the code from "dir='C:/Users/couvreurv/Desktop/MECHA_4Dsolute/'" to the actual directory where the code is located.
When first opening "MECHA4D_trace_optim.m" in Matlab, one needs to update the directory referred to at line 15 of the Matlab script from "data.python_exe_dir='C:\Users\couvreurv\AppData\Local\Continuum\anaconda3\python.exe'" to the actual location of the python.exe file on your computer.
Depending on whether the user has Anaconda and Spyder installed already, installation can take from a few minutes to less than 30 minutes.

3. Demo
To run the demo, simply run "MECHA4D_trace_optim.m" in Matlab.
This demo optimizes the values of xylem water flow rate and diffusion coefficients in cell walls, plasmodesmata and xylem vessels, in order to fit xylem D2O wash-out traces.
The expected output values for parameters should be similar but not equal to the ones reported in the manuscript Supplementary Table 2 because of the random component in the search algorithm.
Running the code typically takes a day or two depending on the specifications of the laptop.

4. Instructions for use
Go to /Projects/Flavius/MECHA4D_trace_optim.m and run this inverse modelling program in Matlab.
Specifically:
- MECHA4D_trace_optim.m runs the optimization;
- run_MECHA_Diff.m runs MECHA_4Dsolute with updated input parameter values;
- Hydr_xml.m writes the input file for hydraulic parameters (in_traces/Hydraulics_optim.xml);
- Geom_xml.m writes the input file for geometrical parameters (in_traces/Geometry_optim.xml);
- BC_xml.m writes the input file for boundary conditions including xylem water flow rate (in_traces/BC_optim.xml);
- Horm_in_xml.m writes the input file for solute transport parameters (in_traces/Hormones_optim.xml) for the D2O wash-in phase;
- Horm_out_xml.m writes the input file for solute transport parameters (in_traces/Hormones_optim.xml) for the D2O wash-out phase;
The .pvtk outputs located in MECHA_4Dsolute\Projects\Flavius\out\M1v4\Arabido\Washin_washout\Optim_traces* can be viewed using the software Paraview.
Output parameter values can be found in the variables explorer and are automatically saved in a *.mat file.
Other pieces of information such as root Lpr (called kr in outputs) can be found in the output file "MECHA_4Dsolute\Projects\Flavius\out\M1v4\Arabido\Washin_washout\Optim_traces1\Macro_prop_*.txt".

For more information, feel free to contact valentin.couvreur@uclouvain.be

