%run_MECHA4D_Diff_optim.m

%Unknows related to traces: Q1, Q2, Q3, Q4, Dxyl, (Dpd, Dwall)
%Unknowns related to Lpr: kw, kAQP, Kpd, (kwbarrier)

restart_fit=1;
%Setting directories
identifier=1;
data.Output_path=['Optim_traces' num2str(identifier)];
data.Input_path='in_traces';
data.MECHA_version='MECHAv4_4Dsolute.py';
data.cdir=cd;
cd ..\..
data.MECHAdir=cd;
data.python_exe_dir='C:\Users\couvreurv\AppData\Local\Continuum\anaconda3\python.exe';
eval(['cd ' data.cdir])

%Importing traces data
lines{1}='Col-0';
lines{2}='pCASP::CDEF';
lines{3}='sgn3*myb36';
Nplants=[30 18 9];
page=[2 6 8];
data.t_norm_ini=[6 6 6];
data.t_norm_ini_sim=[11 2 5];
data.dt_norm=12;
data.time_cc0=600;
Nt_norm=data.time_cc0/data.dt_norm;
t_norm=nan(Nt_norm,3);
avg_norm_out=nan(Nt_norm,3);
std_norm_out=nan(Nt_norm,3);
t=1:1000; %(sec)
data.span_avg_filt=15;

for il=1:3
    raw_data_out=xlsread('PeakArea.xlsx',page(il));
    raw_data_out=raw_data_out(:,1:Nplants(il));
    avg_filt_out=nan(1000,Nplants(il));
    for it=1:1000
        avg_filt_out(it,:)=nanmean(raw_data_out(max(1,it-data.span_avg_filt):min(1000,it+data.span_avg_filt),:));
    end
    
    %Normalization of experimental traces
    data.t_norm(:,il)=data.t_norm_ini(il):data.dt_norm:data.time_cc0; %(s)
    norm_out=nan(length(data.t_norm),Nplants(il));
    for i=1:Nplants(il)
        it_top=find(avg_filt_out(:,i)==max(avg_filt_out(:,i)),1,'last'); %index
        icc0=find(t>=data.time_cc0+t(it_top),1,'first');
        cc0=avg_filt_out(icc0,i); %(D2O fraction)
        cc0_factor=1/(max(avg_filt_out(:,i))-cc0);
        norm_out(:,i)=(avg_filt_out(it_top+data.t_norm_ini(il):data.dt_norm:icc0,i)-cc0)*cc0_factor;
    end
    data.avg_norm_out(:,il)=mean(norm_out,2);
    data.std_norm_out(:,il)=std(norm_out,0,2);
    clear norm_out avg_filt_out raw_data_out
end

% Characteristics of virtual roots
data.lengths=[0.1 0.4 0.5 0.5]; %(mm) [15 25] length of the first and second simulated regions, starting 5 mm from the tip with CS formation and 20 mm from the tip, respectively
data.heights=[0.1 0.1 0.1 0.1]; %(mm) [15 25] length of the first and second simulated regions, starting 5 mm from the tip with CS formation and 20 mm from the tip, respectively
TotLayers=sum(data.lengths./data.heights);
data.Contact=[0 0 99999 0]; % 0: Full contact between root surface and soil water; 99999: No contact with soil water
data.cid=24; % 24: Xylem vessel id
data.iLayer=TotLayers-3;
%Hydraulic conductivity of lignified and suberised cell walls (cm^2/hPa/d)
data.washin_cc=[1 1 0 0]; %Concentration at root surface for each length portion
data.washout_cc=[0 0 0 0]; %Concentration at root surface for each length portion
%Barrier types are as follow: 0: no apoplastic barrier nor mature xylem; 1: endodermal Casparian strip; 2: suberised endodermis with passage cells; 3: fully suberised endodermis
barriers=[1 1 1 3; %Col-0 assumed phene
    1 1 1 1; %pCASP::CDEF assumed phene
    1 1 1 3];%sgn3*esb1 assumed phene
%Hydraulic conductivity of lignified and suberised cell walls (cm^2/hPa/d)
kw_barrier=[1e-16 1e-16 1e-16 1e-16; %Col-0 assumed phene
    1e-16 1e-16 1e-16 1e-16; %pCASP::CDEF assumed phene
    1     1     1     1    ];%sgn3*esb1 assumed phene
%Hydraulic conductivity of primary cell walls (cm^2/hPa/d)
data.kw=2.16e-007;%
%Hydraulic conductance of individual plasmodesmata (cm^3/hPa/d)
data.Kpl=9.11e-013;%
%Aquaporin contribution to cell membranes hydraulic conductivity (cm/hPa/d)
data.kAQP=4.68e-004;%
%esb1 AQP activity ratio
data.esb1_AQP_ratio=0.2;

%Which line?
data.line='A';
             
% Initial guess, lower and higher bounds for cell-scale diffusivity parameters
%          Dif_PW (cm^2/d) Diff_PD (cm^2/d) Diff_X (cm^2/d) Q_xylA (cm^3/d) Q_xylB (cm^3/d) Q_xylC (cm^3/d) Q_xylD (cm^3/d)
data.xl=[  1.0             1.0              1.0             0.001            ];%0.001            0.001            0.001];
data.xu=[  20.0            20.0             20.0            0.020            ];%0.020            0.020            0.020];
x0 = ([    6.0             3.0              15.0            0.005            ]-data.xl)./(data.xu-data.xl);%0.05            0.05            0.05];
param = x0;
data.Nlines=length(param)-3;
xl = zeros(1,data.Nlines+3);
xu = ones(1,data.Nlines+3);

% Optimization options
opts = optimset('Algorithm','interior-point',...
    'Display','iter','TolFun',1e-4,'TolX',1e-2,'MaxFunEvals',100);

% Optimization problem
if restart_fit==1
    data.optim=1;
%     data.trace_meas=norm_out;%(:,i);
%     data.t_norm=t_norm(:,il);
    data.kw_barrier=kw_barrier(il,:);
    data.barriers=barriers(il,:);
    data.il=il;
    
    while exist([data.cdir '/out/M1v4/Arabido/washin_washout/' data.Output_path],'file')
        identifier=identifier+1;
        data.Output_path=['Optim_traces' num2str(identifier)];
    end
    mkdir([data.cdir '/out/M1v4/Arabido/washin_washout/' data.Output_path]);
    data.OPTIM=fopen([data.cdir '/out/M1v4/Arabido/washin_washout/' data.Output_path '/Multistart_log.txt'],'w+');
    data.log_path=[data.cdir '/out/M1v4/Arabido/washin_washout/' data.Output_path '/Multistart_log.txt'];
    temp=['OF ' data.line '               Dif_PW (cm^2/d)    Dif_PD (cm^2/d)    Dif_X (cm^2/d)     Q_xyl ' data.line ' (cm^3/d)'];%   OF ' data.line '             '];
    fprintf(data.OPTIM,'%s\r\n',temp);
    
    problem = createOptimProblem('fmincon','objective',...
        @(param) run_MECHA_Diff(param,data),...
        'x0',x0,'lb',xl,'ub',xu,'options',opts);
    ms = MultiStart;
    
    % Run the optimization
    param_opt = run(ms,problem,5);
    save([data.Output_path '.mat'],'param_opt','x0','data')
    fclose ('all');
else
    load([data.Output_path '.mat'],'param_opt','x0','data')
end
data.optim=0;

% Run the model with optimal parameters
[OF_opt,traces_opt]=run_MECHA_Diff(param_opt,data);

%Display results
Diff_PW = param_opt(1)*(data.xu(1)-data.xl(1))+data.xl(1);
Diff_PD = param_opt(2)*(data.xu(2)-data.xl(2))+data.xl(2);
Diff_X = param_opt(3)*(data.xu(3)-data.xl(3))+data.xl(3);
Q_xyl = param_opt(4)*(data.xu(4)-data.xl(4))+data.xl(4);
disp(['OF_opt = ' num2str(OF_opt) ' Diff_PW = ' num2str(Diff_PW,'%4.2e') ' Diff_PD = ' num2str(Diff_PD,'%4.2e') ' Diff_X = ' num2str(Diff_X,'%4.2e') ' Q_xyl = ' num2str(Q_xyl,'%4.2e')])



%Displaying results
color_code=[0.2 0.2 0.7;
            200*1.2/256 100*1.2/256 70*1.2/256;
            0.66 0.66 0.66;
            ];
if data.line=='A' %~ exist(data.line,'var') || 
    il=1;
elseif data.line=='B'
    il=2;
elseif data.line=='C'
    il=3;
end
figure
hold on
plot(data.t_norm(:,il),data.avg_norm_out(:,il),'Color',color_code(il,:),'LineWidth',3)
plot(data.t_norm(:,il),traces_opt(:,1),'LineWidth',3,'Color',[0.2 0.2 0.2])
for it=1:size(data.t_norm,1)
    plot([data.t_norm(it,il) data.t_norm(it,il)],[data.avg_norm_out(it,il)-data.std_norm_out(it,il) data.avg_norm_out(it,il)+data.std_norm_out(it,il)],'-','Color',color_code(il,:))
end
plot(data.t_norm(:,il),traces_opt(:,1),'LineWidth',3,'Color',[0.2 0.2 0.2])
plot([0 data.time_cc0],[0 0],'k:')
xlabel('Time (s)')
xlim([0 data.time_cc0])
ylabel('Xylem [D_2O] (A.U.)')
ylim([-0.1 1.1])
legend([lines{il} ' measured'],[lines{il} ' simulated'],'Location','NorthEast')


figure
subplot(1,3,2)
hold on
for il=[1 2]
    plot(data.t_norm(:,il),data.avg_norm_out(:,il),'Color',color_code(il,:),'LineWidth',3)
end
for il=[1 2]
    for it=1:size(data.t_norm,1)
        plot([data.t_norm(it,il) data.t_norm(it,il)],[data.avg_norm_out(it,il)-data.std_norm_out(it,il) data.avg_norm_out(it,il)+data.std_norm_out(it,il)],'-','Color',color_code(il,:))
    end
end
plot([0 data.time_cc0],[0 0],'k:')
xlabel('Time (s)')
xlim([0 data.time_cc0])
ylabel('Xylem [D_2O] (A.U.)')
ylim([-0.1 1.1])
legend('WT','CDEF','Location','NorthEast')

subplot(1,3,3)
hold on
for il=[1 3]
    plot(data.t_norm(:,il),data.avg_norm_out(:,il),'Color',color_code(il,:),'LineWidth',3)
end
for il=[1 3]
    for it=1:size(data.t_norm,1)
        plot([data.t_norm(it,il) data.t_norm(it,il)],[data.avg_norm_out(it,il)-data.std_norm_out(it,il) data.avg_norm_out(it,il)+data.std_norm_out(it,il)],'-','Color',color_code(il,:))
    end
end
plot([0 data.time_cc0],[0 0],'k:')
xlabel('Time (s)')
xlim([0 data.time_cc0])
ylabel('Xylem [D_2O] (A.U.)')
ylim([-0.1 1.1])
legend('WT','sgn3 myb36','Location','NorthEast')










