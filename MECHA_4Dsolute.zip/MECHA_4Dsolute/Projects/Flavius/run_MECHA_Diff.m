function [OF,traces_sim]=run_MECHA_Diff(param,data)

% Updating parameters
Diff_PW = param(1)*(data.xu(1)-data.xl(1))+data.xl(1);
Diff_PD = param(2)*(data.xu(2)-data.xl(2))+data.xl(2);
Diff_X = param(3)*(data.xu(3)-data.xl(3))+data.xl(3);
%Q_xyl = nan(data.Nlines,1);
%for i=1:data.Nlines
Q_xyl = param(4)*(data.xu(4)-data.xl(4))+data.xl(4);
%end
traces_sim=nan(size(data.t_norm,1),1);%data.Nlines);

%lines
lines{1}='Col-0';
lines{2}='pCASP::CDEF';
lines{3}='sgn3*myb36';

%Saved traces will include the phenotypes (4), washin + washout (2), time + xylem [D2O] (number of observation times)
%traces=struct(data.Nlines,2,2); %Rows are for lines A-D; Columns for Control vs Azide treatments
%for i=1:data.Nlines
if data.line=='A'
    i=1;
elseif data.line=='B'
    i=2;
elseif data.line=='C'
    i=3;
end
%Creating MECHA input files
%Geometry.xml
Geom_xml(data.Input_path,data.barriers(i,:),data.lengths,data.heights)

%Hydraulics.xml
if data.il==2 %esb1*CDEF has AQP inactivation
    Hydr_xml(data.Input_path,data.Output_path,data.kw,data.kw_barrier,data.kAQP*data.esb1_AQP_ratio,data.Kpl,data.Contact,data.MECHA_version)
else
    Hydr_xml(data.Input_path,data.Output_path,data.kw,data.kw_barrier,data.kAQP,data.Kpl,data.Contact,data.MECHA_version)
end

%BC.xml
BC_xml(data.Input_path,'Washin_washout',Q_xyl)

%Wash-in
%Hormones.xml
Horm_in_xml(data.Input_path,Diff_PD,Diff_PW,Diff_X,data.cid,data.iLayer,data.lengths,data.heights,data.washin_cc)

%Running MECHA
%Also installed pyqt in Canopy to make the script calling from matlab work (in particular, the import of pylab was an issue)
[~, commandOut] = system([data.python_exe_dir ' ' data.MECHAdir '\' data.MECHA_version ' 2']);
if data.optim==0
    disp([lines{i} ' wash-in'])
    fprintf(commandOut);
end

%     %Read trace from MECHA output files
%     Cdata=importdata(['out/M1v4/Arabido/washin_washout/' data.Output_path '\Observation_nodes_cc9,0s1.txt'],'\t',6);
%     %Normalization of trace
%     it_bottom=find(Cdata.data(:,2)==min(Cdata.data(:,2)),1,'last'); %(index)
%     time_cc1=1000; %(s)
%     icc1=find(Cdata.data(:,1)>=time_cc1+Cdata.data(it_bottom,1),1,'first');
%     cc1=Cdata.data(icc1,2); %(D2O fraction)
%     eval(['traces.t' num2str(i) 'in=Cdata.data(it_bottom:icc1,1)-Cdata.data(it_bottom,1);']); %(s) Time since start of wash-in
%     eval(['traces.cc' num2str(i) 'in=Cdata.data(it_bottom:icc1,2)/cc1;']); %(D2O fraction during wash-in)

%Wash-out
Ini_cond=['out\M1v4\Arabido\washin_washout\' data.Output_path '\3D_cc_b9,0,t01.xml'];
%Hormones.xml
Horm_out_xml(data.Input_path,Ini_cond,Diff_PD,Diff_PW,Diff_X,data.cid,data.iLayer,data.lengths,data.heights,data.washout_cc)

%Running MECHA
[~, commandOut] = system([data.python_exe_dir ' ' data.MECHAdir '\' data.MECHA_version ' 2']);
if data.optim==0
    %disp([lines{i} ' wash-out'])
    fprintf(commandOut);
end

%disp(['Import data from output file "''out/M1v4/Arabido/washin_washout/' data.Output_path '/Observation_nodes_cc9,0s1_resume.txt'''])
%Read trace from MECHA output files
try
    Cdata=importdata(['out/M1v4/Arabido/washin_washout/' data.Output_path '/Observation_nodes_cc9,0s1_resume.txt'],'\t',6);
catch
    error('Could not import data from output file')
end
%Application of averaging filter
t_regular=Cdata.data(1,1):Cdata.data(end,1);
Nt_regular=length(t_regular);
[t_irreg,icc]=unique(Cdata.data(:,1),'first');
cc_irreg=Cdata.data(icc,2);
cc_regular=interp1(t_irreg,cc_irreg,t_regular);
cc_regular_filt=nan(Nt_regular,1);
for it=1:Nt_regular
    cc_regular_filt(it)=mean(cc_regular(max(1,it-data.span_avg_filt):min(Nt_regular,it+data.span_avg_filt)));
end

%Normalization of trace
it_top=find(cc_regular_filt==max(cc_regular_filt),1,'last'); %index
icc0=find(t_regular>=data.time_cc0+t_regular(it_top),1,'first');
cc0=cc_regular_filt(icc0); %(D2O fraction)
cc0_factor=1/(max(cc_regular_filt)-cc0);
cc=interp1(t_regular(it_top:icc0)-t_regular(it_top),cc_regular_filt(it_top:icc0),data.t_norm(:,i));
traces_sim(:,1)=(cc-cc0)*cc0_factor; %(D2O fraction during wash-out)
%end

%Calculation of objective function value
OF=sqrt(sum(((traces_sim(:,1)-data.avg_norm_out(:,i))./data.std_norm_out(:,i)).^2)/length(data.avg_norm_out(:,i)));
disp(['OF = ' num2str(OF,'%13.11e') ' Diff_PW = ' num2str(Diff_PW,'%11.9e') ' Diff_PD = ' num2str(Diff_PD,'%11.9e') ' Diff_X = ' num2str(Diff_X,'%11.9e') ' Q_xyl1-end = ' num2str(Q_xyl','%11.9e')])% ' OF1-end = ' num2str(OFi','%11.9e')])

%Write result in log file
if data.optim==1
    fid=fopen(data.log_path,'a');
    fprintf(fid,'%s\r\n',[num2str(OF,'%13.11e') ' ' num2str(Diff_PW,'%13.11e') ' ' num2str(Diff_PD,'%13.11e') ' ' num2str(Diff_X,'%13.11e') ' ' num2str(Q_xyl(1),'%13.11e')]);% ' ' num2str(OFi(1),'%13.11e')]);
    fclose(fid);
end



